import { useState } from 'react';
import { ActivityWizardState } from '@alf/shared';
import { useCreateActivity } from '@alf/shared';
import { useI18nKeys } from '@alf/shared';

interface DicteeActivityFormProps {
    state: ActivityWizardState;
    updateState: (updates: Partial<ActivityWizardState>) => void;
    onSuccess: () => void;
}

export default function DicteeActivityForm({ state, updateState, onSuccess }: DicteeActivityFormProps) {
    const createActivity = useCreateActivity();
    const { data: i18nKey } = useI18nKeys('DicteeActivity');
    
    const [audioUrls, setAudioUrls] = useState<string[]>(['']);
    const [correctText, setCorrectText] = useState('');
    const [caseSensitive, setCaseSensitive] = useState(false);
    const [useCustomInstruction, setUseCustomInstruction] = useState(false);
    const [customInstructionKey, setCustomInstructionKey] = useState('');

    const handleAddAudioUrl = () => {
        setAudioUrls([...audioUrls, '']);
    };

    const handleRemoveAudioUrl = (index: number) => {
        setAudioUrls(audioUrls.filter((_, i) => i !== index));
    };

    const handleAudioUrlChange = (index: number, value: string) => {
        const updated = [...audioUrls];
        updated[index] = value;
        setAudioUrls(updated);
    };

    const validateForm = (): boolean => {
        if (!correctText.trim()) {
            alert('Veuillez entrer le texte correct de la dictée.');
            return false;
        }

        const filteredUrls = audioUrls.filter(url => url.trim());
        if (filteredUrls.length === 0) {
            alert('Veuillez ajouter au moins une URL audio.');
            return false;
        }

        return true;
    };

    const handleSubmit = async (submitForReview: boolean) => {
        if (!validateForm()) return;

        const instructionKey = useCustomInstruction && customInstructionKey.trim()
            ? customInstructionKey.trim()
            : (i18nKey as any)?.key || 'activity.dictee.instruction';

        const payload = {
            activity_type: 'DicteeActivity',
            lesson_id: state.lessonId!,
            instruction_key: instructionKey,
            translation_data: {},
            difficulty: state.difficulty,
            points: state.points,
            order: state.order,
            type_specific_data: {
                audio_urls: audioUrls.filter(url => url.trim()),
                correct_text: correctText.trim(),
                case_sensitive: caseSensitive
            }
        };

        try {
            await createActivity.mutateAsync(payload);
            alert(submitForReview 
                ? 'Activité créée et soumise pour validation !'
                : 'Activité sauvegardée en brouillon !'
            );
            onSuccess();
        } catch (error: any) {
            alert(`Erreur: ${error.response?.data?.message || 'Impossible de créer l\'activité'}`);
        }
    };

    return (
        <div className="space-y-6">
            <div className="bg-blue-50 border-l-4 border-blue-400 p-4 rounded">
                <div className="flex items-start">
                    <div className="text-3xl mr-3">🎵</div>
                    <div>
                        <h3 className="font-semibold text-blue-900">Créer une Dictée</h3>
                        <p className="text-sm text-blue-700 mt-1">
                            L'étudiant écoute un fichier audio et écrit ce qu'il entend en français.
                        </p>
                    </div>
                </div>
            </div>

            {/* Instruction Key */}
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                    📝 Instruction (clé i18n)
                </label>
                
                {!useCustomInstruction ? (
                    <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-mono text-gray-700">
                                {(i18nKey as any)?.key || 'activity.dictee.instruction'}
                            </span>
                            <button
                                type="button"
                                onClick={() => setUseCustomInstruction(true)}
                                className="text-xs text-blue-600 hover:text-blue-800"
                            >
                                Utiliser une clé personnalisée
                            </button>
                        </div>
                        <div className="text-xs text-gray-600 space-y-1">
                            <div>🇫🇷 {(i18nKey as any)?.preview_fr}</div>
                            <div>🇬🇧 {(i18nKey as any)?.preview_en}</div>
                            <div>🇸🇦 {(i18nKey as any)?.preview_ar}</div>
                        </div>
                    </div>
                ) : (
                    <div>
                        <input
                            type="text"
                            value={customInstructionKey}
                            onChange={(e) => setCustomInstructionKey(e.target.value)}
                            placeholder="activity.dictee.custom_instruction"
                            className="w-full border border-gray-300 rounded-lg px-4 py-2 text-base font-mono"
                        />
                        <button
                            type="button"
                            onClick={() => setUseCustomInstruction(false)}
                            className="text-xs text-blue-600 hover:text-blue-800 mt-1"
                        >
                            ← Retour à l'instruction standard
                        </button>
                        <p className="text-xs text-yellow-600 mt-2">
                            ⚠️ Cette clé doit exister dans les fichiers de traduction backend.
                        </p>
                    </div>
                )}
            </div>

            {/* Audio URLs */}
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                    🎧 Fichiers Audio <span className="text-red-500">*</span>
                </label>
                <div className="space-y-3">
                    {audioUrls.map((url, index) => (
                        <div key={index} className="flex items-center gap-2">
                            <input
                                type="text"
                                value={url}
                                onChange={(e) => handleAudioUrlChange(index, e.target.value)}
                                placeholder="/media/audio/phrase.mp3"
                                className="flex-1 border border-gray-300 rounded-lg px-4 py-2 text-base"
                            />
                            {audioUrls.length > 1 && (
                                <button
                                    type="button"
                                    onClick={() => handleRemoveAudioUrl(index)}
                                    className="px-3 py-2 text-red-600 hover:text-red-800 font-medium"
                                >
                                    ✕
                                </button>
                            )}
                        </div>
                    ))}
                    <button
                        type="button"
                        onClick={handleAddAudioUrl}
                        className="text-sm text-blue-600 hover:text-blue-800 font-medium"
                    >
                        + Ajouter un fichier audio
                    </button>
                </div>
                <p className="text-xs text-gray-500 mt-2">
                    💡 Vous pouvez ajouter plusieurs versions (lent, normal, rapide).
                </p>
            </div>

            {/* Correct Text */}
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                    ✍️ Texte Correct (français) <span className="text-red-500">*</span>
                </label>
                <input
                    type="text"
                    value={correctText}
                    onChange={(e) => setCorrectText(e.target.value)}
                    placeholder="Je suis un étudiant."
                    className="w-full border border-gray-300 rounded-lg px-4 py-2 text-base"
                />
                <p className="text-xs text-gray-500 mt-1">
                    Le texte exact que l'étudiant doit écrire.
                </p>
            </div>

            {/* Options */}
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                    ⚙️ Options
                </label>
                <div className="flex items-center">
                    <input
                        type="checkbox"
                        id="caseSensitive"
                        checked={caseSensitive}
                        onChange={(e) => setCaseSensitive(e.target.checked)}
                        className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                    />
                    <label htmlFor="caseSensitive" className="ml-2 text-sm text-gray-700">
                        Sensible à la casse (majuscules/minuscules)
                    </label>
                </div>
            </div>

            {/* Submit Buttons */}
            <div className="flex justify-between items-center pt-6 border-t">
                <div className="text-sm text-gray-500">
                    💾 Les activités sont sauvegardées en brouillon
                </div>
                <div className="flex gap-3">
                    <button
                        type="button"
                        onClick={() => handleSubmit(false)}
                        disabled={createActivity.isPending}
                        className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50"
                    >
                        Sauvegarder en Brouillon
                    </button>
                    <button
                        type="button"
                        onClick={() => handleSubmit(true)}
                        disabled={createActivity.isPending}
                        className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                    >
                        {createActivity.isPending ? 'Création...' : 'Créer l\'Activité'}
                    </button>
                </div>
            </div>
        </div>
    );
}