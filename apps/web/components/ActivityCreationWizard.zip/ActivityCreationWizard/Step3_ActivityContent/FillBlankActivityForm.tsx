import { useState } from 'react';
import { ActivityWizardState } from '@alf/shared';
import { useCreateActivity } from '@alf/shared';
import { useI18nKeys } from '@alf/shared';

interface FillBlankActivityFormProps {
    state: ActivityWizardState;
    updateState: (updates: Partial<ActivityWizardState>) => void;
    onSuccess: () => void;
}

export default function FillBlankActivityForm({ state, updateState, onSuccess }: FillBlankActivityFormProps) {
    const createActivity = useCreateActivity();
    const { data: i18nKey } = useI18nKeys('FillBlankActivity');
    
    const [correctAnswer, setCorrectAnswer] = useState('');
    const [usePhraseKey, setUsePhraseKey] = useState(true);
    const [phraseKey, setPhraseKey] = useState('');
    const [phraseText, setPhraseText] = useState('');
    const [useCustomInstruction, setUseCustomInstruction] = useState(false);
    const [customInstructionKey, setCustomInstructionKey] = useState('');

    const validateForm = (): boolean => {
        if (!correctAnswer.trim()) {
            alert('Veuillez entrer la réponse correcte.');
            return false;
        }

        if (usePhraseKey && !phraseKey.trim()) {
            alert('Veuillez entrer la clé i18n de la phrase.');
            return false;
        }

        if (!usePhraseKey && !phraseText.trim()) {
            alert('Veuillez entrer le texte de la phrase.');
            return false;
        }

        if (!usePhraseKey && phraseText && !phraseText.includes('___') && !phraseText.includes('_')) {
            const confirm = window.confirm(
                'La phrase ne contient pas de blanc (___). Voulez-vous continuer quand même ?'
            );
            if (!confirm) return false;
        }

        return true;
    };

    const handleSubmit = async () => {
        if (!validateForm()) return;

        const instructionKey = useCustomInstruction && customInstructionKey.trim()
            ? customInstructionKey.trim()
            : (i18nKey as any)?.key || 'activity.fill_blank.instruction';

        const payload = {
            activity_type: 'FillBlankActivity',
            lesson_id: state.lessonId!,
            instruction_key: instructionKey,
            translation_data: usePhraseKey && phraseKey.trim() 
                ? { phrase_key: phraseKey.trim() } 
                : {},
            difficulty: state.difficulty,
            points: state.points,
            order: state.order,
            type_specific_data: {
                correct_answer: correctAnswer.trim(),
                phrase_key: usePhraseKey ? phraseKey.trim() : null,
                phrase: !usePhraseKey ? phraseText.trim() : null
            }
        };

        try {
            await createActivity.mutateAsync(payload);
            alert('Activité créée avec succès !');
            onSuccess();
        } catch (error: any) {
            alert(`Erreur: ${error.response?.data?.message || 'Impossible de créer l\'activité'}`);
        }
    };

    return (
        <div className="space-y-6">
            <div className="bg-blue-50 border-l-4 border-blue-400 p-4 rounded">
                <div className="flex items-start">
                    <div className="text-3xl mr-3">✏️</div>
                    <div>
                        <h3 className="font-semibold text-blue-900">Créer un Exercice "Remplir le Blanc"</h3>
                        <p className="text-sm text-blue-700 mt-1">
                            L'étudiant complète une phrase avec le mot ou expression manquant(e).
                        </p>
                    </div>
                </div>
            </div>

            {/* Instruction Key */}
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                    📝 Instruction (clé i18n)
                </label>
                
                {!useCustomInstruction ? (
                    <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-mono text-gray-700">
                                {(i18nKey as any)?.key || 'activity.fill_blank.instruction'}
                            </span>
                            <button
                                type="button"
                                onClick={() => setUseCustomInstruction(true)}
                                className="text-xs text-blue-600 hover:text-blue-800"
                            >
                                Utiliser une clé personnalisée
                            </button>
                        </div>
                        <div className="text-xs text-gray-600 space-y-1">
                            <div>🇫🇷 {(i18nKey as any)?.preview_fr}</div>
                            <div>🇬🇧 {(i18nKey as any)?.preview_en}</div>
                            <div>🇸🇦 {(i18nKey as any)?.preview_ar}</div>
                        </div>
                    </div>
                ) : (
                    <div>
                        <input
                            type="text"
                            value={customInstructionKey}
                            onChange={(e) => setCustomInstructionKey(e.target.value)}
                            placeholder="activity.fill_blank.custom_instruction"
                            className="w-full border border-gray-300 rounded-lg px-4 py-2 text-base font-mono"
                        />
                        <button
                            type="button"
                            onClick={() => setUseCustomInstruction(false)}
                            className="text-xs text-blue-600 hover:text-blue-800 mt-1"
                        >
                            ← Retour à l'instruction standard
                        </button>
                    </div>
                )}
            </div>

            {/* Correct Answer */}
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                    ✅ Réponse Correcte <span className="text-red-500">*</span>
                </label>
                <input
                    type="text"
                    value={correctAnswer}
                    onChange={(e) => setCorrectAnswer(e.target.value)}
                    placeholder="vais"
                    className="w-full border border-gray-300 rounded-lg px-4 py-2 text-base"
                />
                <p className="text-xs text-gray-500 mt-1">
                    Le mot ou expression que l'étudiant doit taper.
                </p>
            </div>

            {/* Phrase Mode Toggle */}
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                    📄 Mode de Phrase
                </label>
                <div className="flex gap-3">
                    <button
                        type="button"
                        onClick={() => setUsePhraseKey(true)}
                        className={`
                            flex-1 px-4 py-3 rounded-lg border-2 text-sm font-medium transition-all
                            ${usePhraseKey 
                                ? 'border-blue-500 bg-blue-50 text-blue-900' 
                                : 'border-gray-200 bg-white text-gray-700 hover:border-gray-300'
                            }
                        `}
                    >
                        {usePhraseKey && '✓ '}
                        Utiliser une clé i18n
                    </button>
                    <button
                        type="button"
                        onClick={() => setUsePhraseKey(false)}
                        className={`
                            flex-1 px-4 py-3 rounded-lg border-2 text-sm font-medium transition-all
                            ${!usePhraseKey 
                                ? 'border-blue-500 bg-blue-50 text-blue-900' 
                                : 'border-gray-200 bg-white text-gray-700 hover:border-gray-300'
                            }
                        `}
                    >
                        {!usePhraseKey && '✓ '}
                        Saisir directement le texte
                    </button>
                </div>
            </div>

            {/* Phrase Input (conditional) */}
            {usePhraseKey ? (
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        🔑 Clé i18n de la Phrase <span className="text-red-500">*</span>
                    </label>
                    <input
                        type="text"
                        value={phraseKey}
                        onChange={(e) => setPhraseKey(e.target.value)}
                        placeholder="phrases.school_go"
                        className="w-full border border-gray-300 rounded-lg px-4 py-2 text-base font-mono"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                        Exemple: <code>phrases.school_go</code> → "Je ___ à l'école."
                    </p>
                    <p className="text-xs text-yellow-600 mt-2">
                        ⚠️ Cette clé doit être définie dans les fichiers de traduction backend et contenir <code>___</code> pour le blanc.
                    </p>
                </div>
            ) : (
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        📝 Phrase avec Blanc <span className="text-red-500">*</span>
                    </label>
                    <textarea
                        value={phraseText}
                        onChange={(e) => setPhraseText(e.target.value)}
                        placeholder="Je ___ à l'école."
                        rows={3}
                        className="w-full border border-gray-300 rounded-lg px-4 py-2 text-base"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                        Utilisez <code>___</code> (trois underscores) pour indiquer le blanc.
                    </p>
                </div>
            )}

            {/* Submit Buttons */}
            <div className="flex justify-between items-center pt-6 border-t">
                <div className="text-sm text-gray-500">
                    💾 Activité sauvegardée en brouillon
                </div>
                <button
                    type="button"
                    onClick={handleSubmit}
                    disabled={createActivity.isPending}
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                    {createActivity.isPending ? 'Création...' : 'Créer l\'Activité'}
                </button>
            </div>
        </div>
    );
}