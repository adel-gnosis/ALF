import { useEffect } from 'react';
import { 
    ActivityWizardState, 
    ActivityType,
    ACTIVITY_TYPE_INFO 
} from '@alf/shared';
import { 
    useCourses, 
    useLevels, 
    useSubjects, 
    useLessons,
    useAvailableActivityTypes 
} from '@alf/shared';

import {
  BookOpen,
  Layers,
  Headphones,
  FileText,
  MessageCircle,
  Pencil,
  AudioLines,
  Users,
  RotateCw,
  Mic,
  Sparkles,
} from "lucide-react";

const SUBJECT_ICON_MAP: Record<string, React.ComponentType<any>> = {
  "book-open": BookOpen,
  "layers": Layers,
  "headphones": Headphones,
  "file-text": FileText,
  "message-circle": MessageCircle,
  "pencil": Pencil,
  "waveform": AudioLines,
  "users": Users,
  "rotate-cw": RotateCw,
  "mic": Mic,
};

function normalizeIconName(raw?: string | null) {
  if (!raw) return "";
  return raw.trim().toLowerCase().replaceAll("_", "-");
}

function SubjectIcon({ name }: { name?: string | null }) {
  const key = normalizeIconName(name);
  const Icon = SUBJECT_ICON_MAP[key] || Sparkles; // fallback
  return <Icon className="h-5 w-5" />;
}


interface Step1Props {
    state: ActivityWizardState;
    updateState: (updates: Partial<ActivityWizardState>) => void;
}

export default function Step1_ContextSelector({ state, updateState }: Step1Props) {
    const { data: courses, isLoading: loadingCourses } = useCourses();
    const { data: levels, isLoading: loadingLevels } = useLevels(state.courseId);
    const { data: subjects, isLoading: loadingSubjects } = useSubjects(state.courseId);
    const { data: lessonsData, isLoading: loadingLessons } = useLessons(state.levelId, state.subjectId);

    // Auto-select first course on mount (French by default)
    useEffect(() => {
        if (courses && courses.length > 0 && !state.courseId) {
            updateState({ courseId: courses[0].id });
        }
    }, [courses]);

    // Get selected subject to filter activity types
    const selectedSubject = subjects?.find(s => s.id === state.subjectId);
    const availableActivityTypes = useAvailableActivityTypes(selectedSubject?.code || null);

    // Filter activity types based on subject
    const filteredActivityTypes = state.subjectId
        ? availableActivityTypes
        : Object.keys(ACTIVITY_TYPE_INFO) as ActivityType[];

    return (
        <div className="space-y-6">
            {/* Course Selector */}
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                    1️⃣ Cours <span className="text-red-500">*</span>
                </label>
                {loadingCourses ? (
                    <div className="text-sm text-gray-500">Chargement...</div>
                ) : (
                    <select
                        value={state.courseId || ''}
                        onChange={(e) => {
                            const courseId = parseInt(e.target.value);
                            updateState({ 
                                courseId,
                                levelId: null,
                                subjectId: null,
                                lessonId: null
                            });
                        }}
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 text-base"
                    >
                        <option value="">Sélectionner un cours...</option>
                        {courses?.map(course => (
                            <option key={course.id} value={course.id}>
                                {course.flag_icon} {course.title}
                            </option>
                        ))}
                    </select>
                )}
                {state.validationErrors.courseId && (
                    <p className="text-red-500 text-sm mt-1">{state.validationErrors.courseId}</p>
                )}
            </div>

            {/* Level Selector */}
            {state.courseId && (
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        2️⃣ Niveau <span className="text-red-500">*</span>
                    </label>
                    {loadingLevels ? (
                        <div className="text-sm text-gray-500">Chargement des niveaux...</div>
                    ) : (
                        <select
                            value={state.levelId || ''}
                            onChange={(e) => {
                                const levelId = parseInt(e.target.value);
                                updateState({
                                levelId,
                                lessonId: null,
                                activityType: null,
                                });

                            }}
                            className="w-full border border-gray-300 rounded-lg px-4 py-3 text-base"
                        >
                            <option value="">Sélectionner un niveau...</option>
                            {levels?.map(level => (
                                <option key={level.id} value={level.id}>
                                    {level.code} - {level.title}
                                </option>
                            ))}
                        </select>
                    )}
                    {state.validationErrors.levelId && (
                        <p className="text-red-500 text-sm mt-1">{state.validationErrors.levelId}</p>
                    )}
                    {levels && levels.length === 0 && (
                        <p className="text-yellow-600 text-sm mt-1">
                            Aucun niveau trouvé pour ce cours.
                        </p>
                    )}
                </div>
            )}

            {/* Subject Selector */}
            {state.courseId && (
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                3️⃣ Sujet (Thème) <span className="text-red-500">*</span>
                </label>

                {loadingSubjects ? (
                <div className="text-sm text-gray-500">Chargement des sujets...</div>
                ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {subjects?.map((subject) => {
                    const isSelected = state.subjectId === subject.id;
                    const color = subject.color || "#CBD5E1"; // fallback

                    return (
                        <button
                        key={subject.id}
                        type="button"
                        onClick={() => {
                            updateState({
                            subjectId: subject.id,
                            lessonId: null,
                            activityType: null,
                            });
                        }}
                        className={[
                            "group relative w-full rounded-2xl border-2 p-4 text-left transition-all",
                            "hover:shadow-md hover:-translate-y-[1px] active:translate-y-0",
                            isSelected
                            ? "border-gray-900 bg-gray-900 text-white shadow-lg"
                            : "border-gray-200 bg-white hover:border-gray-300",
                        ].join(" ")}
                        >
                        <div className="flex items-start gap-3">
                            {/* color dot */}
                            <div
                            className="mt-1 h-3 w-3 rounded-full"
                            style={{ backgroundColor: color }}
                            />

                            <div className="flex-1">
                            <div className="flex items-center gap-2">
                                <div className={isSelected ? "text-white" : "text-gray-900"}>
                                <SubjectIcon name={subject.icon} />
                                </div>

                                <div className="font-semibold">
                                {subject.title}
                                </div>
                            </div>

                            <div className={isSelected ? "mt-1 text-xs text-gray-300" : "mt-1 text-xs text-gray-500"}>
                                {subject.code}
                            </div>
                            </div>

                            {isSelected && (
                            <div className="text-xs font-semibold bg-white/10 px-2 py-1 rounded-full">
                                Sélectionné
                            </div>
                            )}
                        </div>

                        {/* nice bottom accent bar */}
                        <div
                            className="pointer-events-none absolute inset-x-0 bottom-0 h-1 rounded-b-2xl opacity-90"
                            style={{ backgroundColor: color }}
                        />
                        </button>
                    );
                    })}
                </div>
                )}

                {state.validationErrors.subjectId && (
                <p className="text-red-500 text-sm mt-1">
                    {state.validationErrors.subjectId}
                </p>
                )}
            </div>
            )}




            {/* Lesson Selector */}
            {state.levelId && state.subjectId && (
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        4️⃣ Leçon <span className="text-red-500">*</span>
                    </label>
                    {loadingLessons ? (
                        <div className="text-sm text-gray-500">Chargement des leçons...</div>
                    ) : (
                        <>
                            <select
                                value={state.lessonId || ''}
                                onChange={(e) => {
                                    const lessonId = parseInt(e.target.value);
                                    updateState({ lessonId });
                                }}
                                className="w-full border border-gray-300 rounded-lg px-4 py-3 text-base"
                            >
                                <option value="">Sélectionner une leçon...</option>
                                {lessonsData?.lessons.map(lesson => (
                                    <option key={lesson.id} value={lesson.id}>
                                        {lesson.title}
                                    </option>
                                ))}
                            </select>
                            <p className="text-xs text-gray-500 mt-1">
                                {lessonsData?.count || 0} leçon(s) disponible(s)
                            </p>
                        </>
                    )}
                    {state.validationErrors.lessonId && (
                        <p className="text-red-500 text-sm mt-1">{state.validationErrors.lessonId}</p>
                    )}
                </div>
            )}

            {/* Activity Type Selector */}
            {state.lessonId && (
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        5️⃣ Type d'Activité <span className="text-red-500">*</span>
                    </label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {filteredActivityTypes.map((type) => {
                            const info = ACTIVITY_TYPE_INFO[type];
                            const isSelected = state.activityType === type;
                            const isAdvanced = info.complexity === 'advanced';

                            return (
                                <button
                                    key={type}
                                    type="button"
                                    onClick={() => updateState({ activityType: type })}
                                    className={`
                                        relative p-4 border-2 rounded-lg text-left transition-all
                                        ${isSelected 
                                            ? 'border-blue-500 bg-blue-50' 
                                            : 'border-gray-200 hover:border-blue-300'
                                        }
                                        ${isAdvanced ? 'opacity-60' : ''}
                                    `}
                                >
                                    <div className="text-3xl mb-2">{info.icon}</div>
                                    <div className="font-semibold text-sm text-gray-900">
                                        {info.label}
                                    </div>
                                    <div className="text-xs text-gray-500 mt-1">
                                        {info.description}
                                    </div>
                                    {isAdvanced && (
                                        <div className="absolute top-2 right-2 bg-yellow-100 text-yellow-800 text-xs px-2 py-0.5 rounded">
                                            Phase 2
                                        </div>
                                    )}
                                </button>
                            );
                        })}
                    </div>
                    {state.validationErrors.activityType && (
                        <p className="text-red-500 text-sm mt-2">{state.validationErrors.activityType}</p>
                    )}
                    {selectedSubject && (
                        <p className="text-xs text-gray-500 mt-2">
                            💡 Types d'activités disponibles pour "{selectedSubject.title}"
                        </p>
                    )}
                </div>
            )}
        </div>
    );
}