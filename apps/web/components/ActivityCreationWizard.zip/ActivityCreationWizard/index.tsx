import { useState } from 'react';
import { ActivityWizardState, Difficulty } from '@alf/shared';
import Step1_ContextSelector from './Step1_ContextSelector';
import Step2_Summary from './Step2_Summary';
import Step3_ActivityContent from './Step3_ActivityContent';

interface ActivityCreationWizardProps {
    isOpen: boolean;
    onClose: () => void;
    onSuccess?: () => void;
}

export default function ActivityCreationWizard({ 
    isOpen, 
    onClose, 
    onSuccess 
}: ActivityCreationWizardProps) {
    const [wizardState, setWizardState] = useState<ActivityWizardState>({
        // Step 1
        courseId: null,
        levelId: null,
        subjectId: null,
        lessonId: null,
        activityType: null,
        
        // Step 2
        difficulty: Difficulty.MEDIUM,
        points: 10,
        order: 0,
        
        // Step 3
        instructionKey: '',
        questionTextKey: '',
        explanationKey: '',
        translationData: {},
        typeSpecificData: {},
        
        // Meta
        currentStep: 1,
        validationErrors: {}
    });

    const updateState = (updates: Partial<ActivityWizardState>) => {
        setWizardState(prev => ({ ...prev, ...updates }));
    };

    const goToStep = (step: 1 | 2 | 3) => {
        setWizardState(prev => ({ ...prev, currentStep: step }));
    };

    const validateStep1 = (): boolean => {
        const errors: Record<string, string> = {};
        
        if (!wizardState.courseId) errors.courseId = 'Sélectionnez un cours';
        if (!wizardState.levelId) errors.levelId = 'Sélectionnez un niveau';
        if (!wizardState.subjectId) errors.subjectId = 'Sélectionnez un sujet';
        if (!wizardState.lessonId) errors.lessonId = 'Sélectionnez une leçon';
        if (!wizardState.activityType) errors.activityType = 'Sélectionnez un type d\'activité';
        
        setWizardState(prev => ({ ...prev, validationErrors: errors }));
        return Object.keys(errors).length === 0;
    };

    const handleNext = () => {
        if (wizardState.currentStep === 1) {
            if (validateStep1()) {
                goToStep(2);
            }
        } else if (wizardState.currentStep === 2) {
            goToStep(3);
        }
    };

    const handleBack = () => {
        if (wizardState.currentStep > 1) {
            goToStep((wizardState.currentStep - 1) as 1 | 2);
        }
    };

    const handleReset = () => {
        setWizardState({
            courseId: null,
            levelId: null,
            subjectId: null,
            lessonId: null,
            activityType: null,
            difficulty: Difficulty.MEDIUM,
            points: 10,
            order: 0,
            instructionKey: '',
            questionTextKey: '',
            explanationKey: '',
            translationData: {},
            typeSpecificData: {},
            currentStep: 1,
            validationErrors: {}
        });
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 overflow-y-auto">
            <div className="bg-white rounded-lg shadow-xl max-w-5xl w-full mx-4 my-8 max-h-[90vh] overflow-y-auto">
                {/* Header */}
                <div className="sticky top-0 bg-white border-b px-6 py-4 z-10">
                    <div className="flex justify-between items-center">
                        <div>
                            <h2 className="text-2xl font-bold text-gray-900">
                                📚 Nouvelle Activité
                            </h2>
                            <p className="text-sm text-gray-500 mt-1">
                                {wizardState.currentStep === 1 && 'Configuration de base'}
                                {wizardState.currentStep === 2 && 'Résumé et paramètres'}
                                {wizardState.currentStep === 3 && 'Contenu de l\'activité'}
                            </p>
                        </div>
                        <button 
                            onClick={onClose} 
                            className="text-gray-400 hover:text-gray-600 text-2xl"
                        >
                            &times;
                        </button>
                    </div>

                    {/* Progress Stepper */}
                    <div className="flex items-center justify-center mt-6 space-x-4">
                        {[1, 2, 3].map((step) => (
                            <div key={step} className="flex items-center">
                                <div className={`
                                    w-10 h-10 rounded-full flex items-center justify-center font-semibold
                                    ${wizardState.currentStep === step 
                                        ? 'bg-blue-600 text-white' 
                                        : wizardState.currentStep > step
                                            ? 'bg-green-500 text-white'
                                            : 'bg-gray-200 text-gray-600'
                                    }
                                `}>
                                    {wizardState.currentStep > step ? '✓' : step}
                                </div>
                                {step < 3 && (
                                    <div className={`
                                        w-24 h-1 mx-2
                                        ${wizardState.currentStep > step ? 'bg-green-500' : 'bg-gray-200'}
                                    `} />
                                )}
                            </div>
                        ))}
                    </div>
                </div>

                {/* Step Content */}
                <div className="p-6">
                    {wizardState.currentStep === 1 && (
                        <Step1_ContextSelector 
                            state={wizardState}
                            updateState={updateState}
                        />
                    )}
                    
                    {wizardState.currentStep === 2 && (
                        <Step2_Summary 
                            state={wizardState}
                            updateState={updateState}
                        />
                    )}
                    
                    {wizardState.currentStep === 3 && (
                        <Step3_ActivityContent 
                            state={wizardState}
                            updateState={updateState}
                            onSuccess={() => {
                                onSuccess?.();
                                handleReset();
                                onClose();
                            }}
                        />
                    )}
                </div>

                {/* Footer Navigation */}
                {wizardState.currentStep < 3 && (
                    <div className="sticky bottom-0 bg-gray-50 border-t px-6 py-4 flex justify-between">
                        <button
                            onClick={wizardState.currentStep === 1 ? onClose : handleBack}
                            className="px-6 py-2 border border-gray-300 rounded text-gray-700 hover:bg-gray-100"
                        >
                            {wizardState.currentStep === 1 ? 'Annuler' : '← Retour'}
                        </button>
                        <button
                            onClick={handleNext}
                            className="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                        >
                            Suivant →
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}